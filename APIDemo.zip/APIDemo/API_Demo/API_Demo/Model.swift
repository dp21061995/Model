//
//  Model.swift
//  API_Demo
//
//  Created by vishal on 8/9/18.
//  Copyright © 2018 echo. All rights reserved.
//

import UIKit

class Model: NSObject {

    /* Local Variable */
    
    //1
    var strNickName : String!
    
    func setUserData(data: JSON) {
        
        strNickName = data["nickname"].string ?? ""
    }
    
    //2
    var redirectpage : String?
    var status : String?
    var branch : String?
    var lastname : String?
    var firstname : String?
    var seckey : String?
    var rolename : String?
    var message : String?
    var userrole : String?
 
    init(jsonObject json : JSON)
    {
        self.redirectpage = json["redirectpage"].stringValue
        self.status = json["status"].stringValue
        self.branch = json["branch"].stringValue
        self.lastname = json["lastname"].stringValue
        self.firstname = json["firstname"].stringValue
        self.seckey = json["seckey"].stringValue
        self.rolename = json["rolename"].stringValue
        self.message = json["message"].stringValue
        self.userrole = json["userrole"].stringValue
    }
    
    static var loginData : Model?
    
}
